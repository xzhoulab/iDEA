########################################
## iDEA Project
## Editor : Shiquan Sun
## Date   : 2019-2-4 13:43:16
## Modified: 2019-3-11 18:06:53
########################################


#' The iDEA Class
#'
#' The iDEA object stores all information
#' associated with the dataset, including data, annotations, analyes, etc. 
#'
#' Each iDEA object has a number of slots which store information. Key slots to access
#' are listed below.
#'
#' @slot summary The summary data from DE method
#' @slot annotation The gene specific annotations
#' @slot project The sub project name
#' @slot gene_id The gene names
#' @slot annot_id The annotation names
#' @slot weight  The weight for each gene for weighted version code
#' @slot num_gene The number of genes
#' @slot num_core The number of cores in parallel running
#' @slot null_model The model under the null
#' @slot emmcmc The results are from EM-MCMC step
#' @slot louis The final results after Louis correction

#'
#' @name iDEA
#' @aliases iDEA-class
#' @exportClass iDEA
#' @importFrom Rcpp evalCpp
#' @useDynLib iDEA

## to creat a new object for the project
setClass("iDEA", slots=list(
	summary = "data.frame",
	annotation = "list",
	project = "character",
	gene_id = "character",
	annot_id = "character",
	weight = "data.frame",
	num_gene = "numeric",
	num_core = "numeric",
	null_model = "list",
	emmcmc = "list",
	louis = "data.frame"
) )


#' Setup the iDEA object, 
#'
#' @param summary Summary statistics (the estimated gene effect size and its variance, g1 x 2 matrix) from single-cell RNAseq differential expression tools, i.g. zingeR, MAST, etc. 
#' @param annotation (required) Pre-definted gene specific annotations (gene sets, g2 x m matrix), i.e., GO term, pathways etc.
#' @param counts Raw scRNAseq counts to obtain the summary data
#' @param cell_type Cell type of the counts data
#' @param method the DE method to obtain the summary data
#' @param project Project name (string).
#' @param max_var_beta Include genes where the variances which are smaller than 'max_var_beta' are maintained  .
#' @param min_precent_annot The threshold of coverage rate (CR), i.e., the number of annotated genes (gene set size) divided by the number of tested genes.
#' @param num_core Number of cores for parallel implementation.
#' @import parallel
#' @import methods
#' 
#' @return Returns a iDEA object with the summary statistics stored in object@summary and object@annotation.
#' object@project, object@num_core, object@num_gene, object@num_annot, object@gene_id, object@annot_id, are also initialized.
#'
#' @export
#'

CreateiDEAObject <- function(summary=NULL, annotation, 
							counts=NULL, cell_type=NULL,
							method="DESeq2",
							project="iDEA", max_var_beta=100, 
							min_precent_annot=0.005, num_core=10){
	if(is.null(summary) & !is.null(counts) & !is.null(cell_type) ){
		cat(paste("## fitting the differential expression model ... \n"))
		cat(paste("## using ",method," to obtain summary data... \n"))
		counts <- counts[rowSums(counts)>0,] # remove 0 read genes
		summary <- GetSummaryData(counts=counts, celltype=cell_type, method=method)
	}# end fi
	## check data fromat
	if(!is.data.frame(summary)){
		summary <- as.data.frame(summary)
	}# end fi
	colnames(summary) <- c("beta", "beta_var")
	keep_index <- summary$beta_var<max_var_beta & !is.na(summary$beta_var)
	summary <- as.data.frame(summary[keep_index,])
	
	if(!is.data.frame(annotation)){
		annotation <- as.data.frame(annotation)
	}# end fi
	
	# On Windows, set cores to be 1 because of mclapply
	if(.Platform$OS.type == "windows"){num_core <- 1}
	
	## merge two data with gene names
	if(nrow(summary) != nrow(annotation)){
		summary$GeneID <- rownames(summary)
		annotation$GeneID <- rownames(annotation)
		combined_data <- merge(summary, annotation, by="GeneID")
		summary <- combined_data[, 2:3]
		rownames(summary) <- combined_data$GeneID
		annotation <- combined_data[, 4:ncol(combined_data)]
		rownames(annotation) <- combined_data$GeneID
		rm(combined_data)
	}# end fi
	
	## number of genes
	num_gene <- nrow(annotation)
	precent_annot <- apply(annotation, 2, sum)/num_gene
	## filtering out at specificed precentage genes are annotated, 
	annotation <- annotation[, which(precent_annot>min_precent_annot)] #  
	
	## convert annotation into list
	annot_list <- mclapply(1:ncol(annotation), FUN = function(x) { which(annotation[,x]==1) }, mc.cores = getOption("mc.cores", num_core)
	)# end parallel
	names(annot_list) <- colnames(annotation)
	## inheriting
	object <- new(
		Class = "iDEA",
		gene_id = rownames(annotation),
		annot_id = colnames(annotation),
		summary = summary,
		annotation = annot_list,
		num_gene = num_gene,
		num_core = num_core,
		project = project
	)
	return(object)
}# end function


#' Compute the weight for each gene to construct gene-gene correlation
#'
#' @param counts Raw count data, each column is a cell and each row is a gene.
#' @param normalization Bool variable to denote whether to do normalization before computing the weight, The default is TRUE.
#' @param lib_size Read deepth for each cell, For default, summarize all read counts across whole genes.
#' @param method The method to compute correlation matrix, pearson (default).
#' 
#' @return Return the weight for each gene, p x 1 vector
#'
#' @export
#'
ComputeWeight <- function(counts, normalization=TRUE, lib_size=NULL, method="pearson"){
	## compute r square
	if(normalization){
		data_fpkm <- QQNorm(counts, lib_size=lib_size)
	}else{
		data_fpkm <- counts
	}#end fi
	rm(counts)
	rsq <- cor(t(data_fpkm), method=method)^2
	## alternatively we can remove the jth gene itself
	weight <- apply(rsq, 2, sum)
	## return weight for each gene
	return(1.0/weight)
}# end func


#' Quantile-Quantile normalization for count data
#'
#' @param counts Raw count data, each column is a cell and each row is a gene.
#' @param lib_size Read deepth for each cell, For default, summarize all read counts across whole genes.
#' 
#' @return Return normalized data
#'
#' @export
#'

QQNorm <- function(counts, lib_size=NULL){
	
	## compute read deepth
	if(is.null(lib_size)){
		lib_size <- apply(counts, 2, sum)
	}# end fi
	
	num_gene <- nrow(counts)
	num_cell <- ncol(counts)

	norm_counts <- apply(counts, 1, function(x){
		m <- x/lib_size
		n <- as.matrix(m)
		s <- sample(num_cell, num_cell, replace=F)
		n[s] <- qqnorm(n[s], plot.it=F)$x
		return(n)
	} )
	colnames(norm_counts) <- colnames(counts)
	rownames(norm_counts) <- rownames(counts)
	## return cell length parameter
	return(norm_counts)
}# end func



